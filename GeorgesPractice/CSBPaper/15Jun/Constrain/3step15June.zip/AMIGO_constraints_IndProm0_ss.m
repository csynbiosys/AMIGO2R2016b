problem.neq=0;
problem.c_L(1,1)=-inf;
problem.c_U(1,1)=0.000010;
